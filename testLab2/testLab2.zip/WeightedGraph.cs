// Modified by Jong-Young Choi
// ---------------
//CSCI 303 Lab #2
// Implement the Graph ADT in C# using the Graph class stub supplied at the end of these instructions.
// Our graphs are simple and undirected. It is your responsibility as class designer to enforce these rules.
// Make sure that each of your class methods is functional.
// You may add members to the Graph class, but do not add class variables which are for local use only, do not change the names or signatures of the methods given in the stub, and do not add to the public interface.
// Make sure that your name appears in a comment at the top of each source file.
// In a new C# source file, derive a class WeightedGraph from your Graph class.
// A weighted graph should have edge weights of type double, and the class consumer should be able to get and set the edge weights.
// In the WeightedGraph class, implement Kruskal's Algorithm in a public method named minWeightSpanningTree.
// Test your lab code using Test Plan #2.
// Submit your source code and your test results in separate files, after first compressing them into a single file using the built-in Windows file compression utility, resulting in a .zip file.


using System;
using System.Collections.Generic;

namespace testLab2
{
    class WeightedGraph : Graph
    {
        private class WeightedEdge : IComparable
        {
            public int vertex1 { get; set; }
            public int vertex2 { get; set; }
            public double weight { get; set; }

            public WeightedEdge(int firstVertex, int secondVertex, double theWeight)
            {
                vertex1 = firstVertex;
                vertex2 = secondVertex;
                weight = theWeight;
            }

            public int CompareTo(object other) // other should be of type 
            {
                if(!(other is WeightedEdge))
                {
                    throw new Exception("Type mismatch: cannot compare type WeightedEdge to type " + other.GetType());
                }
                
                WeightedEdge otherEdge = (WeightedEdge)other;
                return weight.CompareTo(otherEdge.weight);
            }
        }

        private double[,] edgeWeights;
        //private object[] vertices; // NO!!!! vertices are inherited!
        public WeightedGraph(int numVertices) : base(numVertices) // base is similar with 'super' in Java. Invoke constructor.
        {
            //vertices = new object[numVertices]; // illegal. vertices array is private. If we chagne private to protected, it works.
            //Also, we declare it, vertices array will lost before data and declared new one.
            edgeWeights = new double[numVertices, numVertices];
        }

        public double getEdgeWeight(int vertex1, int vertex2)
        {
            isValidEdge(vertex1, vertex2);
            return edgeWeights[vertex1, vertex2];
        }

        public void setEdgeWeight(int vertex1, int vertex2, double theWeight)
        {
            isValidEdge(vertex1, vertex2);
            edgeWeights[vertex1, vertex2] = theWeight;
            edgeWeights[vertex2, vertex1] = theWeight;
        }

        // custom method added        
        private void isValidEdge(int vertex1, int vertex2)
        {
            if (vertex1 == vertex2)
            {
                throw Exception("Do not input loop");
            }
            if (vertex1 >= getNumVertices() || vertex1 < 0)
            {
                throw Exception("Invalid vertex1 number.");
            }
            if (vertex2 >= getNumVertices() || vertex2 < 0)
            {
                throw Exception("Invalid vertex2 number.");
            }
            if (hasEdge(vertex1, vertex2) == false)
            {
                throw Exception("No Edge existed.");
            }
        }

        public WeightedGraph minWeightSpanningTree()
        {
             // 0. Make a copy C of W with the same vertices as W, but no edges;
             // 1. Sort all the edges of W in increasing order of weight;
             // 2. Add the next edge of the sorted list to C,
             //    unless doing so would produce a cycle in C;
             // 3. If C is not connected, then go to Step 2.

            if(!isConnected())
            {
                throw new Exception("Invoking graph is not connected, has no spanning trees!");
            }
            // Step 0
            int n = getNumVertices();
            WeightedGraph T = new WeightedGraph(n);
            var edgeArray = new List<WeightedEdge>();
            for(int i=0; i<n; i++)
            {
                for(int j=0; j<n; j++)
                {
                    if(i == j)
                    {
                        continue;
                    }

                    if(hasEdge(i,j))
                    {
                        edgeArray.Add(new WeightedEdge(i, j, edgeWeights[i,j]));
                    }
                }
            }
            // Step 1
            edgeArray.Sort();
            // Step 2,3
            for(int i = 0; !T.isConnected(); i++)
            {
                // add next edge of invoking graph to T (already sorted)
                WeightedEdge we = edgeArray[i];
                T.addEdge(we.vertex1, we.vertex2);
                T.edgeWeights[we.vertex1, we.vertex2] = we.weight;
                if(T.hasCycle())
                {
                    T.removeEdge(we.vertex1, we.vertex2);
                }
            }
            return T;
        }
    }
}