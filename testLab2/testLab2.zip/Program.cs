﻿// Modified by Jong-Young Choi
// ---------------
using System;

namespace testLab2
{
    class Program
    {
        static public void showTest(Graph g, bool connectedness, bool cycles, bool tree)
        {
            //(d)tests g for connectedness;
            Console.WriteLine("\r\nConnectedness : " + g.isConnected());
            // expected results:
            Console.WriteLine("Expected : " + connectedness);
            // True

            //(e)tests g for cycles;
            Console.WriteLine("\r\nhasCycle : " + g.hasCycle());
            // expected results:
            Console.WriteLine("Expected : " + cycles);
            // False

            //(f)tests whether g is a tree.
            Console.WriteLine("\r\nisTree : " + g.isTree());
            //expected results:
            Console.WriteLine("Expected : " + tree);
            // True
        }

        static void Main(string[] args)
        {
            //1.Write C# code that does each of the following tasks. For parts (d), (e), and (f), also find the expected result and explain how you got it.
            //(a) creates a Graph g with 128 vertices;
            Console.WriteLine("Test 1");
            // CALL graph's int constructor.
            // syntax is same as for Java:
            int graphSize = 128;
            Graph g = new Graph(graphSize);
            //(b)stores the numbers 0 through 127 in the vertices, in that order;
            for (int i = 0; i < graphSize; i++)
            {
                //g.addVertexData(i, g.getVertexData(i));
                g.addVertexData(i, i);
            }

            //(c)joins all pairs of vertices of the form {j, j / 2}
            //where j is between 1 and 127, and where j / 2 is computed as usual with integer division;
            for(int j=1; j< graphSize; j++)
            {
                if( j == j/2 )
                {
                    continue;
                }
                g.addEdge(j, j/2);
            }
            showTest(g, true, false, true);

//      2.Write C# code that starts with the graph g built in problem 1 above, then removes the edge from 1 to 3, and tests again for connectedness, cycles, and tree-ness.
//       expected results:
            Console.WriteLine("\r\nTest2. E(1,3) will be removed.");
            g.removeEdge(1,3);
            showTest(g, false, false, false);
//      3.Write C# code that starts with the Graph g in the state after problem 2 above, then adds a new edge from 111 to 112. Test again for connectedness, cycles, and tree-ness.
//      expected results:
            Console.WriteLine("\r\nTest3. E(111,112) will be added.");
            g.addEdge(111,112);
            showTest(g, false, false, false);

//      4.Write C# code that starts with the Graph g in the state after problem 3 above, then adds back the edge from 1 to 3. Test again for connectedness, cycles, and tree-ness.
//      expected results:
            Console.WriteLine("\r\nTest4. E(1,3) will be added again.");
            g.addEdge(1,3);
            showTest(g, true, true, false);

//       5.Write C# code that does each of the following tasks.
            Console.WriteLine("\r\nTest5.");
//      (a) Creates a weighted graph wg with 5 vertices(note that the vertices will be numbered 0 through 4);
            int gwSize = 5;
            WeightedGraph wg = new WeightedGraph(gwSize);

            int limit = wg.getNumVertices();
            for(int i=0; i < limit; i++)
            {
                wg.addVertexData(i, i);
            }
//      (b) adds edges between every pair of vertices in wg to create a "complete" graph;
            for(int i = 0; i < limit - 1; i++)
            {
                for(int j = i + 1; j < limit; j++)
                {
                    wg.addEdge(i,j);
                }
            }
//      (c) adds edge weights to wg so that the weight of the edge {a, b} is equal to 1.0 / ((a^2 + b^2 - ab) % 11 + 1);
            for(int i = 0; i < limit - 1; i++)
            {
                for(int j = i + 1; j < limit; j++)
                {
                    double weight = (i*i + j*j - i*j) % 11 + 1;
                    weight = 1.0 / weight;
                    wg.setEdgeWeight(i, j, weight);
                }
            }
//      (d) displays a minimum-weight spanning tree t in wg using Kruskal's Algorithm.
            WeightedGraph t = wg.minWeightSpanningTree();
            Console.WriteLine(t);


//       6.Show the work for problem 5(d) manually and give the expected result.


        }// end main method
    }// end program class 

} // namespace
