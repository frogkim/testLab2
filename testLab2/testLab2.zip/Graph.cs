﻿// Modified by Jong-Young Choi
// ---------------

using System;
using System.Collections.Generic;
using System.Text;

namespace testLab2
{
    class Graph
    {
        private object[] vertices;
        private bool[,] edges;
        private bool test;
        private bool connect;
        private bool cycle;
        private bool tree;

        public Graph(int numVertices)
        {
            vertices = new object[numVertices];
            edges = new bool[numVertices, numVertices];
            test = false;
            connect = false;
            cycle = false;
            tree = false;
        }
        public void addVertexData(int vertexNumber, object vertexData)
        {
            if(vertexNumber >= vertices.Length || vertexNumber < 0)
            {
                throw Exception("Invalid vertex number.");
            }
            test = false; // data is changed. It is needed to test again
            vertices[vertexNumber] = vertexData;
        }

        public void addEdge(int vertex1, int vertex2)
        {
            if(vertex1 == vertex2)
            { 
                throw Exception("Do not input loop"); 
            }
            if(vertex1 >= vertices.Length || vertex1 < 0)
            {
                throw Exception("Invalid vertex1 number.");
            }
            if(vertex2 >= vertices.Length || vertex2 < 0)
            {
                throw Exception("Invalid vertex2 number.");
            }
            test = false; // data is changed. It is needed to test again
            edges[vertex1, vertex2] = true;
            edges[vertex2, vertex1] = true;
        }
        public void removeEdge(int vertex1, int vertex2)
        {
            if (vertex1 == vertex2)
            {
                throw Exception("Do not input loop");
            }
            if (vertex1 >= vertices.Length || vertex1 < 0)
            {
                throw Exception("Invalid vertex1 number.");
            }
            if (vertex2 >= vertices.Length || vertex2 < 0)
            {
                throw Exception("Invalid vertex2 number.");
            }
            test = false; // data is changed. It is needed to test again
            edges[vertex1, vertex2] = false;
            edges[vertex2, vertex1] = false;
        }
        public bool hasEdge(int vertex1, int vertex2)
        {
            if (vertex1 == vertex2)
            {
                throw Exception("Do not input loop");
            }
            if (vertex1 >= vertices.Length || vertex1 < 0)
            {
                throw Exception("Invalid vertex1 number.");
            }
            if (vertex2 >= vertices.Length || vertex2 < 0)
            {
                throw Exception("Invalid vertex2 number.");
            }
            if (edges[vertex1, vertex2] == true) return true;
            else return false;
        }
        public object getVertexData(int vertexNumber)
        {
            if(vertexNumber >= vertices.Length || vertexNumber < 0)
            {
                throw Exception("Invalid vertex number.");
            }
            return vertices[vertexNumber];
        }
        public int getNumVertices()
        {
            return vertices.Length;
        }
        public bool isConnected()
        {
            if (!test)
            {
                testGraph();
            }
            return connect;
        }

        public bool hasCycle()
        {
            if (!test)
            {
                testGraph();
            }
            return cycle;
        }
        public bool isTree()
        {
            if (!test)
            {
                testGraph();
            }
            return tree;
        }

        private void testGraph()
        {
            // cycle is tested in DFS_recursive
            cycle = false;
            int[] testVertices = DFS(0);

            // connect test
            connect = true;
            for(int i=0; i<testVertices.Length; i++)
            {
                if(testVertices[i] == 0)
                {
                    connect = false;
                }
            }

            if( connect == true && cycle == false )
            {
                tree = true;
            }
            else
            {
                tree = false;
            }
            
            test = true;
        }

        private int[] DFS(int a)
        {
            int[] verticeDFS = new int[vertices.Length];
            int previous = 0;
            int order = 1;
            DFS_Recursive(0, verticeDFS, previous, ref order);
            return verticeDFS;
        }
        private void DFS_Recursive(int current, int[] verticeArray, int previous, ref int order)
        {
            verticeArray[current] = order;
            order++;
            // find neighbor
            for(int next=0; next < vertices.Length; next++)
            {
                if (current == next)
                {
                    continue;   // no loop
                }
                if (previous == next)
                {
                    continue;
                }
                if(edges[current, next] == true) // if i is neighbor, visit it.
                {
                    // cycle
                    // 1. neighbor - checked
                    // 2. alreadyt visited
                    // 3. not previous - checked
                    if (verticeArray[next] > 0)
                    {
                        cycle = true;
                        continue;
                    }
                    DFS_Recursive(next, verticeArray, current, ref order);
                }
            }
        }
        protected Exception Exception(string s)
        {
            Console.WriteLine(s);
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            string ret = "";
            ret += "This graph has " + getNumVertices() + " verticies.";
            ret += "\r\n";
            ret += "This vertex information is as follows: ";
            for(int i = 0; i < getNumVertices(); i++)
            {
                ret += "\r\n";
                ret += "vertex #" + i + " contains " + vertices[i];
            }
            ret += "\r\n";
            ret += "The edge are as follows";
            bool atLeastOneEdgeExists = false;
            for(int i = 0; i < getNumVertices(); i++)
            {
                for(int j = 0; j < i; j++)
                {
                    if(i == j)
                    {
                        continue;
                    }
                    if(hasEdge(i, j))
                    {
                        atLeastOneEdgeExists = true;
                        ret += "\r\n";
                        ret += "{" + i + "," + j + "}";
                    }
                }
            }
            if(!atLeastOneEdgeExists)
            {
                ret += "\r\n";
                ret += "NO EDGES TO SEE!";
            }
            return ret;
        }
    } // end class Graph
} // end namespace testLab2
